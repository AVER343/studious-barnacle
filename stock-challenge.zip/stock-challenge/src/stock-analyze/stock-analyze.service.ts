import { Injectable } from '@nestjs/common';

@Injectable()
export class StockAnalyzeService {
    analyzeStock(symbol:string,candles:number[]){
        const sum = candles.reduce((prev,curr)=>prev+curr,0);
        const avg = sum/Math.max(candles.length,1);
        let suggestion = avg > candles[candles.length-1] ? "BUY":"SELL"
        return {action:suggestion,sma:avg}
    }
}
