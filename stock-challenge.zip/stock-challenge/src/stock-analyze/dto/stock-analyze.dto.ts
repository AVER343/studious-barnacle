import { IsArray, IsEmail, IsNotEmpty, IsObject, IsString } from 'class-validator';
export class StockAnalyzeDTO { 
    
  @IsString()
  symbol: string;

  @IsArray()
  candles: number[];
}