import { Test, TestingModule } from '@nestjs/testing';
import { StockAnalyzeService } from './stock-analyze.service';

describe('StockAnalyzeService', () => {
  let service: StockAnalyzeService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [StockAnalyzeService],
    }).compile();

    service = module.get<StockAnalyzeService>(StockAnalyzeService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
