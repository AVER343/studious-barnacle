import { Module } from '@nestjs/common';
import { StockAnalyzeController } from './stock-analyze.controller';
import { StockAnalyzeService } from './stock-analyze.service';

@Module({
  controllers: [StockAnalyzeController],
  providers: [StockAnalyzeService]
})
export class StockAnalyzeModule {}
