import { Body, Controller, ForbiddenException, Get, Post } from '@nestjs/common';
import { StockAnalyzeService } from './stock-analyze.service';
import { StockAnalyzeDTO } from './dto/stock-analyze.dto';

@Controller('trade')
export class StockAnalyzeController {
    constructor(private readonly stockerService:StockAnalyzeService){}
    @Post('/analyze')
    analyzeTrade(@Body() tradeDTO:StockAnalyzeDTO){
        try {const result = this.stockerService.analyzeStock(tradeDTO.symbol,tradeDTO.candles);
        return result;}catch(e){
            throw new ForbiddenException("Error ")
        }
    }
}
