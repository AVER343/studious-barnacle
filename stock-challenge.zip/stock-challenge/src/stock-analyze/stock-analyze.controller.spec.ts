import { Test, TestingModule } from '@nestjs/testing';
import { StockAnalyzeController } from './stock-analyze.controller';

describe('StockAnalyzeController', () => {
  let controller: StockAnalyzeController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [StockAnalyzeController],
    }).compile();

    controller = module.get<StockAnalyzeController>(StockAnalyzeController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
